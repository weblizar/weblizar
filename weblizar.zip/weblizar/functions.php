<?php
/*	*Theme Name	: Weblizar
	*Theme Core Functions and Codes
*/	
	/**Includes reqired resources here**/
	require( get_template_directory() . '/core/menu/weblizar_bootstrap_navwalker.php' ); // for Default Menus
	require( get_template_directory() . '/core/menu/default_menu_walker.php' ); // for Default Menus
	require( get_template_directory() . '/core/comment-box/comment-function.php' ); //for comments
	require(get_template_directory()  . '/customizer.php');
	require(get_template_directory()  . '/core/custom-header.php');	
	
	define('WEBLIZAR_THEME_URL', 'https://weblizar.com/themes/weblizar-premium-theme/');
	define('WEBLIZAR_THEME_REVIEW_URL', 'https://wordpress.org/support/theme/weblizar/reviews/?filter=5');

	add_action( 'after_setup_theme', 'wl_setup' ); 	
	function wl_setup()
	{	
		add_theme_support( 'title-tag' );
		add_theme_support( "responsive-embeds" );
		add_theme_support( 'woocommerce' );
		add_theme_support( 'wc-product-gallery-zoom' );
	    add_theme_support( 'wc-product-gallery-lightbox' );
	    add_theme_support( 'wc-product-gallery-slider' );
		global $content_width;
		//content width
		if ( ! isset( $content_width ) ) $content_width = 720; //px
	
		// Load text domain for translation-ready
		load_theme_textdomain( 'weblizar');	
		
		add_theme_support( 'post-thumbnails' ); //supports featured image
		// This theme uses wp_nav_menu() in one location.
		register_nav_menu( 'primary', __( 'Primary Menu', 'weblizar' ) );
		add_theme_support( 'customize-selective-refresh-widgets' );

		/* Gutenberg */
		add_theme_support( 'wp-block-styles' );
		add_theme_support( 'align-wide' );

		/* Add editor style. */
		add_theme_support( 'editor-styles' );
		add_theme_support( 'dark-editor-style' );

		/* Allow shortcodes in widgets. */
		add_filter( 'widget_text', 'do_shortcode' );
		
		// Logo
		add_theme_support( 'custom-logo', array(
			'width'       => 250,
			'height'      => 250,
			'flex-width'  => true,
			'flex-height' => true,
			'header-text' => array( 'site-title', 'site-description' ),
		));
		// theme support 	
		$args = array('default-color' => '000000',);
		add_theme_support( 'custom-background', $args); 
		add_theme_support( 'automatic-feed-links');
		add_theme_support( 'html5');
		add_editor_style();
	}
	
	
	function weblizar_scripts()	{	
		wp_enqueue_style( 'weblizar-style', get_stylesheet_uri() );
		//** font-awesome-4.7.0 **//
		wp_enqueue_style('weblizar-font-awesome-latest', get_template_directory_uri(). '/css/font-awesome-5.11.2/css/all.css');
		wp_enqueue_style('weblizar-bootstrap', get_template_directory_uri() . '/css/bootstrap.css');
		wp_enqueue_style( 'slicknav',   get_template_directory_uri() . '/css/slicknav.css' );
		wp_enqueue_style( 'slick',   get_template_directory_uri() . '/css/slick.css' );
		wp_enqueue_style( 'slicktheme',   get_template_directory_uri() . '/css/slick-theme.css' );
		wp_enqueue_style('weblizar-responsive', get_template_directory_uri() . '/css/responsive.css');
		wp_enqueue_style('weblizar-flat-blue', get_template_directory_uri() . '/css/skins/flat-blue.css');	
		wp_enqueue_style('weblizar-theme-menu', get_template_directory_uri() . '/css/theme-menu.css');
		wp_enqueue_style('weblizar-carousel', get_template_directory_uri() . '/css/carousel.css');
		wp_enqueue_style('weblizar-swiper-css', get_template_directory_uri() . '/css/swiper.css');
		// Js
		wp_enqueue_script( 'jquery-slicknav',  get_template_directory_uri() . '/js/jquery.slicknav.js', array( 'jquery' ), true, true); 
		wp_enqueue_script( 'slick-js', 	       get_template_directory_uri() . '/js/slick.js', array( 'jquery' ), true, true);	
		wp_enqueue_script('weblizar-bootstrap', get_template_directory_uri() .'/js/bootstrap.js', array( 'jquery' ), true, true);
		wp_enqueue_script('weblizar-theme-menu', get_template_directory_uri() .'/js/menu.js', array('jquery'), true, true );		
		wp_enqueue_script('weblizar-swiper', get_template_directory_uri() .'/js/swiper.js', array( 'jquery' ), true, true);	

		$count_posts = wp_count_posts();
		$published_posts = $count_posts->publish;
		$blog_count = get_theme_mod('blog_count');
		$slider_image_speed = get_theme_mod('slider_image_speed','2000');
		$sticky_header = get_theme_mod('sticky_header','off');
		wp_enqueue_script('weblizar-more-posts', get_template_directory_uri() .'/js/more-posts.js', array( 'jquery' ), true, true);	
		wp_localize_script('weblizar-more-posts', 'load_more_posts_var', array(
				'counts' => $published_posts,
				'blog_count' => $blog_count
			)
		);

		$ajax_data = array(
            'image_speed'     => $slider_image_speed,
            'sticky_header'   => $sticky_header,
        );

        wp_enqueue_script( 'weblizar-ajax-front', get_template_directory_uri() . '/js/weblizar-ajax-front.js', array( 'jquery' ), true, true );
        wp_localize_script( 'weblizar-ajax-front', 'ajax_admin', array(
                'ajax_url'    => admin_url( 'admin-ajax.php' ),
                'admin_nonce' => wp_create_nonce( 'admin_ajax_nonce' ),
                'ajax_data'   => $ajax_data,
        ) );
	}
	add_action('wp_enqueue_scripts', 'weblizar_scripts'); 
	if ( is_singular() ) wp_enqueue_script( "comment-reply" ); 

	// Read more tag to formatting in blog page 
	function weblizar_content_more($more)
	{  global $post;							
	   return '<div class="blog-post-details-item blog-read-more"><a href="'.esc_url(get_permalink(),'weblizar').'">'.esc_html_e("Read More...","weblizar").'</a></div>';
	}   
	add_filter( 'the_content_more_link', 'weblizar_content_more' );
	
	/*
	* Weblizar widget area
	*/
	add_action( 'widgets_init', 'weblizar_widgets_init');
	function weblizar_widgets_init() {
	/*sidebar*/
	register_sidebar( array(
			'name' => __( 'Sidebar', 'weblizar' ),
			'id' => 'sidebar-primary',
			'description' => __( 'The primary widget area', 'weblizar' ),
			'before_widget' => '<div id="%1$s" class="sidebar-block %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<h3 class="h3-sidebar-title sidebar-title">',
			'after_title' => '</h3>'
		) );

	register_sidebar( array(
			'name' => __( 'Footer Widget Area', 'weblizar' ),
			'id' => 'footer-widget-area',
			'description' => __( 'footer widget area', 'weblizar' ),
			'before_widget' => '<div id="%1$s" class="col-md-3 col-sm-3 footer-col %2$s">',
			'after_widget' => '</div>',
			'before_title' => '<div class="footer-title">',
			'after_title' => '</div>',
		) );             
	}
	
	/*
	* Image resize and crop
	*/
	if ( ( 'add_image_size' ) ) 
	{ 
		add_image_size('wl_media_sidebar_img',54,54,true);
		add_image_size('wl_media_blog_img',800,400,true);
		add_image_size('wl_blog_img',350,150,true);
	}


function weblizar_add_editor_styles() {
    $font_url = str_replace( ',', '%2C', '//fonts.googleapis.com/css?family=Lato:300,400,700' );
    add_editor_style( $font_url );
}
add_action( 'after_setup_theme', 'weblizar_add_editor_styles' );

add_action( 'wp_enqueue_scripts', 'weblizar_custom_css' );
function weblizar_custom_css() {
    $output = '';
	$output .= 'ul.post-footer {
				text-align: center;
				list-style: none;
				margin-top: 50px;
			}';
	$output .= '.item {
			  margin-bottom: 30px;
			}';
	$output .= 'a.append-button.btn.btn-color{
				background-color: #3498db;
				border: 1px solid transparent;
				color: #fff;
				font-size: 21px;
				border-radius: 6px;
				line-height: 1.4;
			}';
	$output .= 'a.append-button.btn.btn-color:hover {
			  opacity: 0.9;
			  color: #fff;
			}';

	$output .= '.logo a img {
			  height: '. get_theme_mod('logo_height') .'px;
			  width: '. get_theme_mod('logo_width') .'px;
			}';

	//custom css
	$custom_css = get_theme_mod('custom_css') ; 
	if (!empty ($custom_css)) {
        $output .= get_theme_mod('custom_css') . "\n";
    }

    wp_register_style( 'weblizar-custom-header-style', false );
    wp_enqueue_style( 'weblizar-custom-header-style', get_template_directory_uri() . '/css/custom-header-style.css' );
    wp_add_inline_style('weblizar-custom-header-style', $output );
}