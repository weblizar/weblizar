jQuery(document).ready(function() {
/*	if( jQuery(window).width() > 767) {
	   jQuery('.nav li.dropdown').hover(function() {
		   jQuery(this).addClass('open');
	   }, function() {
		   jQuery(this).removeClass('open');
	   }); 
	   jQuery('.nav li.dropdown-submenu').hover(function() {
		   jQuery(this).addClass('open');
	   }, function() {
		   jQuery(this).removeClass('open');
	   }); 
	}*/
	
	jQuery('li.dropdown').find('.fa-angle-down').each(function(){
		jQuery(this).on('click', function(){
			if( jQuery(window).width() < 767) {
				jQuery(this).parent().next().slideToggle();
			}
			return false;
		});
	});
/* Theme Info Page Menu */
	var active_menu;
	jQuery('.theme-menu').click(function(){
		active_menu=jQuery(this).attr('id');
		jQuery('.theme-menu').removeClass('active');
		jQuery(this).addClass('active');
		jQuery('.p_front').removeClass('active');
		jQuery('.p_front.'+active_menu).addClass('active');
	});
	});

 /*====================================
      slick nav
  ======================================*/
  var logo_path = jQuery('.mobile-menu').data('logo');
  var logo_link = jQuery('.mobile-menu').data('link');
  var logo_type = jQuery('.mobile-menu').data('type');
  let logo;

    if (logo_type === 'text') {
      logo = '<a href="' + logo_link + '"></a>';
    }else {
      logo = '<a href="' + logo_link + '"><img src="' + logo_path + '" class="img-fluid" alt="logo"></a>';;
    }

  jQuery('.navbar-nav').slicknav({
    appendTo: '.mobile-menu',
    removeClasses: true,
    label: '',
    closedSymbol: '<i class="fa fa-angle-right"><i/>',
    openedSymbol: '<i class="fa fa-angle-down"><i/>',
    brand: logo
  });

    function weblizar_toggle_icon_burger() {

        const list = document.querySelectorAll(".slicknav_nav li a");

            // get first element to be focused inside modal
            const firstFocusableElement = document.getElementById('slicknav_btnn');

            const logo = document.querySelector('.logo a');

            const firstFocusableElementclass = document.querySelector('.slicknav_collapsed');

            // get last element to be focused inside modal
            const last = list[list.length - 1];
            const lastFocusableElement = last;

            document.addEventListener('keydown', function (e) {
                let isTabPressed = e.key === 'Tab' || e.keyCode === 9;

                if (!isTabPressed) {
                    return;
                }

                if(event.shiftKey && event.keyCode == 9 && document.activeElement === firstFocusableElement) { 
              
                    lastFocusableElement.focus();
                    e.preventDefault();
                }
                if(event.shiftKey && event.keyCode == 9 && document.activeElement === firstFocusableElementclass) { 
              
                  logo.focus();
                    e.preventDefault();
                }

                // if shift key pressed for shift + tab combination
                if (e.shiftKey) {
                    if (document.activeElement === firstFocusableElement) {
                        lastFocusableElement.focus();
                        e.preventDefault();
                    }
                } else {
                    if (document.activeElement === lastFocusableElement) {
                        firstFocusableElement.focus();
                        e.preventDefault();
                    }
                }
            });
    }
weblizar_toggle_icon_burger();