jQuery(document).ready(function ($) {
   jQuery( '#accordion-section-themes' ).prepend('<a href="https://weblizar.com"> <img class="wl-upload-img-tag" src="'+gif_image.image_url+'" /></a>');
});